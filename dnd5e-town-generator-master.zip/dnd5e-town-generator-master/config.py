SECRET = "CHANGE-ME"
# Change the SECRET if you don't want your towns to be unique.
# This is useful for DMs, because your players can only view your generated towns
# if they know what the SECRET was that you used.
# (In other words, if no-one knows what SECRET you use, then  no-one can see your towns.)
#
# Examples of SECRET values are:
# SECRET = "f89wurniout8944ucuwioy98wevstuiu4soiytiue4ucuioshevui5fys"
# SECRET = "I-WISH-I-COULDVE-GOTTEN-WITH-RYAN-ON-THAT-COOL-RETREAT-JAN-HAS-PLASTIC-BOOBS-I-HAVE-HEMORRHOIDS"
# SECRET = "uds987rujkwreR#RWEtu8er9uoiwjlrrgERYRTttter34ure"
# SECRET = "79283yrhsklfhwfSDWE%$W*Riestu439rueoiursdj"



PREMIUM = False
# Set PREMIUM to False if:
#   - You don't want others to overload the program;
#   - You want to allow multiple users to use this program simultaneously;
#   - Your computer doesn't handle huge calculations well.
#
# Set PREMIUM to "True" if:
#   - You want to go wild with creating crazy town sizes;
#   - You're okay with your computer being a bit slower during the calculations;
#   - There's no more than a handful of people who will use the program, (i.e, you're alone).